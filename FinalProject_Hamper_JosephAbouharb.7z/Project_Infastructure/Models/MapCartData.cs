﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Infastructure.Models
{
	public class MapCartData
	{
		public int HamperId { get; set; }
		public string HamperName { get; set; }

		public decimal Cost { get; set; }

		public int Quantity { get; set; }

		
	}
}
