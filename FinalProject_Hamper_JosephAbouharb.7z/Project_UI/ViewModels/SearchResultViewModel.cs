﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Project_Infastructure.Models;
namespace Project_UI.ViewModels
{
	public class SearchResultViewModel
	{
		public IEnumerable<Hamper> Hampers { get; set; }

	}
}
