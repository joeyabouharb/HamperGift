﻿$(function () {
    $("#accordion").accordion({
        heightStyle: "content"
    });
});